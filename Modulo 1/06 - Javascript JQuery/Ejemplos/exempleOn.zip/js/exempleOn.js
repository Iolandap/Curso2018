/* $(document).ready(function(){
    $("button#add").click(function() {
        var html = "<button class='alert'>Alert!</button>";
        $("button.alert:last").parent().append(html);
    });

    $("button.alert").click(function() {
        alert(1);
    });
}); */

 $(document).ready(function(){
    $("button#add").click(function() {
        var html = "<button class='alert'>Alert!</button>";
        $("button.alert:last").parent().append(html);
    });
    
    $("div#container").on('click', 'button.alert', function() {
        alert(1);
    });

/*    $("button.alert").on('click', function() {
        alert(1);
    });*/
}); 