<head>
    <link href="css/footer.css" rel="stylesheet" type="text/css" media="screen" />
</head> 

<footer>
    <div class="container">
        <div class="row">
            <div class="col-sm">
                <p>&#169;2018 Yo mismo</p> 
            </div>
        </div>
        <p>Este sitio web puede utilizar algunas <em>'cookies'</em> para mejorar su experiencia de navegación. Por favor, antes de continuar con su navegación por nuestro sitio web, le recomendamos que lea la 
        	<!-- Politica cookies con llamada a Modal -->
            <a href="#" style="color:orange" data-toggle="modal" data-target="#politica_cookies">
                política de cookies
            </a>
        </p>
    </div>
</footer>