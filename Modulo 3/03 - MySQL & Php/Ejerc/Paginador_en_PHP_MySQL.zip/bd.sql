CREATE DATABASE turl;

CREATE TABLE `ejemplo_paginacion` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(45) NOT NULL,
  `Apellido` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
); 

INSERT INTO `ejemplo_paginacion` VALUES ('2', 'NICK', 'WAHLBERG');
INSERT INTO `ejemplo_paginacion` VALUES ('3', 'ED', 'CHASE');
INSERT INTO `ejemplo_paginacion` VALUES ('4', 'JENNIFER', 'DAVIS');
INSERT INTO `ejemplo_paginacion` VALUES ('5', 'JOHNNY', 'LOLLOBRIGIDA');
INSERT INTO `ejemplo_paginacion` VALUES ('6', 'BETTE', 'NICHOLSON');
INSERT INTO `ejemplo_paginacion` VALUES ('7', 'GRACE', 'MOSTEL');
INSERT INTO `ejemplo_paginacion` VALUES ('8', 'MATTHEW', 'JOHANSSON');
INSERT INTO `ejemplo_paginacion` VALUES ('9', 'JOE', 'SWANK');
INSERT INTO `ejemplo_paginacion` VALUES ('10', 'CHRISTIAN', 'GABLE');
INSERT INTO `ejemplo_paginacion` VALUES ('11', 'ZERO', 'CAGE');
INSERT INTO `ejemplo_paginacion` VALUES ('12', 'KARL', 'BERRY');
INSERT INTO `ejemplo_paginacion` VALUES ('13', 'UMA', 'WOOD');
INSERT INTO `ejemplo_paginacion` VALUES ('14', 'VIVIEN', 'BERGEN');
INSERT INTO `ejemplo_paginacion` VALUES ('15', 'CUBA', 'OLIVIER');
INSERT INTO `ejemplo_paginacion` VALUES ('16', 'FRED', 'COSTNER');
INSERT INTO `ejemplo_paginacion` VALUES ('17', 'HELEN', 'VOIGHT');
INSERT INTO `ejemplo_paginacion` VALUES ('18', 'DAN', 'TORN');
INSERT INTO `ejemplo_paginacion` VALUES ('19', 'BOB', 'FAWCETT');
INSERT INTO `ejemplo_paginacion` VALUES ('20', 'LUCILLE', 'TRACY');
INSERT INTO `ejemplo_paginacion` VALUES ('21', 'KIRSTEN', 'PALTROW');
INSERT INTO `ejemplo_paginacion` VALUES ('22', 'ELVIS', 'MARX');
INSERT INTO `ejemplo_paginacion` VALUES ('23', 'SANDRA', 'KILMER');
INSERT INTO `ejemplo_paginacion` VALUES ('24', 'CAMERON', 'STREEP');
INSERT INTO `ejemplo_paginacion` VALUES ('25', 'KEVIN', 'BLOOM');
INSERT INTO `ejemplo_paginacion` VALUES ('26', 'RIP', 'CRAWFORD');
INSERT INTO `ejemplo_paginacion` VALUES ('27', 'JULIA', 'MCQUEEN');
INSERT INTO `ejemplo_paginacion` VALUES ('28', 'WOODY', 'HOFFMAN');
INSERT INTO `ejemplo_paginacion` VALUES ('29', 'ALEC', 'WAYNE');
INSERT INTO `ejemplo_paginacion` VALUES ('30', 'SANDRA', 'PECK');
INSERT INTO `ejemplo_paginacion` VALUES ('31', 'SISSY', 'SOBIESKI');
INSERT INTO `ejemplo_paginacion` VALUES ('32', 'TIM', 'HACKMAN');
INSERT INTO `ejemplo_paginacion` VALUES ('33', 'MILLA', 'PECK');
INSERT INTO `ejemplo_paginacion` VALUES ('34', 'AUDREY', 'OLIVIER');
INSERT INTO `ejemplo_paginacion` VALUES ('35', 'JUDY', 'DEAN');
INSERT INTO `ejemplo_paginacion` VALUES ('36', 'BURT', 'DUKAKIS');
INSERT INTO `ejemplo_paginacion` VALUES ('37', 'VAL', 'BOLGER');
INSERT INTO `ejemplo_paginacion` VALUES ('38', 'TOM', 'MCKELLEN');
