
<head>
   	<link rel="stylesheet" type="text/css" href="css/cabecera.css" title="style">
</head>

<header>
	<h2>Menu productos</h2>

	<ul>
	  <li><a href="index.php?pagina=1">	Home			</a></li>
	  <li><a href="index.php?pagina=2">	Insertar		</a></li>
	  <li><a href="index.php?pagina=3">	Listar & Borrar	</a></li>
	  <li><a href="index.php?pagina=4">	Galeria Imagenes</a></li>
	  <li><a href="index.php?pagina=5">	Sobre nosotros	</a></li>
	</ul>
</header>