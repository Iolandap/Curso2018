<?php session_staç(); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<?php 
if(isset($_POST["enviar"])){
	$user = $_POST["user"];
	$password = $_POST["password"];


	$conecion = mysqli_connect("localhost","root", "","empresa");

	$sql="SELECT tipus, CONCAT(nombre, ' ',apellidos) as nomC FROM usuaris WHERE user='$user' and  password ='$password'";

	$res = mysqli_query($conecion,$sql);

	$nfilas = mysqli_num_rows($res);
	mysqli_close($conecion);
	if($nfilas>0){

		$fila = mysqli_fetch_assoc($res);

		$_SESSION['nomC'] = $fila["nomC"].;
		$_SESSION["tipo"]= $fila["tipus"];

		header("Location: home.php");

	}else{
		header("Location: index.php?er=1");
	}
}
?>

<form action="login.php" method="post">
	<input type="text" name="user">
	<input type="password" name="password">
	<input type="submit" name="enviar" value="Enviar">
</form>

</body>
</html>