<?php 

$conecion = mysqli_connect("localhost","root", "","vuelos_ikram");
?>